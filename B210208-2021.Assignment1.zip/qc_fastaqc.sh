#!/usr/bin/bash

# This script will assess the quality checks outputted from the FASTQC programme, display the results in a meaningful manner, and ask the user if they would like to proceed.

#The files will be gzipped and each file will have a corresponding directory with the directory name like "----"_fastqc
#Need to loop over each directory and look at summary files



#Print for each file what parameters passed or failed

#If the file failed certain parameters or an abritrary number of parameters ; print a warning message about the sequences 

#Ask User if they would wish to proceed
