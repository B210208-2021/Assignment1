#!/usr/bin/bash

#Variable 1 is the path to the file 
PATH= $1

cd $PATH
for file in (ls $PATH/*.fq.gz)
do 
fastqc $file -o ~/Assignment1/
done
