#!/usr/bin/bash

TC=$1

#Run the bowtie2 script
source bowtie2_1.sh $TC

#Run the bedtools script
source bedtools_av.sh

#Run the Fold Change Script
source fold_changes.sh
 
