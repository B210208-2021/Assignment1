#!/usr/bin/bash

# Three Scripts that take a list of WT, C1, and C2
#Loop over the WT output files from sorting_script.sh 
#Loop over file names in each file to sort into bam 1, 2 and 3
# Generate counts data for 3 separate files and output file with gene name, gene description, file1 count, file2 count and file3 count
# Then want to sum either individual columns and get mean and/or all columns and get mean
#Print that output to a file for each WT, C1, and C2
#A script that generates count data for the 3 separate  files and outputs the file with the gene name, gene description, file1 count, file2 count, file3 count

#WT
for file in $(ls *_WT_files.txt);
do
filename=`basename $file _files.txt` 
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{ total += $3 } END { print "Av of Replicate 1\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $4 } END { print "Av of Replicate 2\t"  total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $5 } END { print "Av of Replicate 3\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ R1 += $3 } {R2 += $4 } {R3 += $5 }; {total = R1 + R2 + R3} END { print "Av of All Replicates\t"  total/(NR*3) }' "$filename"_counts.txt >> "$filename"_av_counts.txt
done



#C1
for file in $(ls *_C1_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{ total += $3 } END { print "Av of Replicate 1\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $4 } END { print "Av of Replicate 2\t"  total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $5 } END { print "Av of Replicate 3\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ R1 += $3 } {R2 += $4 } {R3 += $5 }; {total = R1 + R2 + R3} END { print "Av of All Replicates\t"  total/(NR*3) }' "$filename"_counts.txt >> "$filename"_av_counts.txt
done

#C2
for file in $(ls *_C2_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{ total += $3 } END { print "Av of Replicate 1\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $4 } END { print "Av of Replicate 2\t"  total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ total += $5 } END { print "Av of Replicate 3\t" total/NR }' "$filename"_counts.txt >> "$filename"_av_counts.txt
awk -F '\t' '{ R1 += $3 } {R2 += $4 } {R3 += $5 }; {total = R1 + R2 + R3} END { print "Av of All Replicates\t"  total/(NR*3) }' "$filename"_counts.txt >> "$filename"_av_counts.txt
done


