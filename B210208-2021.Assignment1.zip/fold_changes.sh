#!/usr/bin/bash

#List the files _*_av_counts.txt
#Loop over these files and make a column for each filename 
#Print the gene name and description 
#Cut and paste the column 6 in each file under the heading 


#WT 
#List the WT_av_count.txt files, sort them numerically, and output to new file
ls *_WT_av_counts.txt | sort  > total_WT_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_WT_av_counts.txt/ /g' total_WT_av_counts.txt | sort  > sed.total_WT_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_WT_av_counts.txt;
do 
for l in total_WT_av_counts.txt;
do 
#Define variables to hold the Gene Name and the Description Headings
name="Gene_Name"
des="Gene_Description"
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed 
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced 
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > WT_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - WT_fold_changes_wo_header.txt > WT_fold_changes.txt
done 
done 

#C1
#List the C1_av_count.txt files, sort them numerically, and output to new file
ls *_C1_av_counts.txt | sort  > total_C1_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_C1_av_counts.txt/ /g' total_C1_av_counts.txt | sort  > sed.total_C1_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_C1_av_counts.txt;
do
for l in total_C1_av_counts.txt;
do
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > C1_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - C1_fold_changes_wo_header.txt > C1_fold_changes.txt
done
done

#C2
#List the C2_av_count.txt files, sort them numerically, and output to new file
ls *_C2_av_counts.txt | sort  > total_C2_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_C2_av_counts.txt/ /g' total_C2_av_counts.txt | sort  > sed.total_C2_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_C2_av_counts.txt;
do
for l in total_C2_av_counts.txt;
do
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > C2_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - C2_fold_changes_wo_header.txt > C2_fold_changes.txt
done
done


#WT VS C1
# Cut and Paste the columns of the two files WT_fold_changes.txt and C1_fold_changes.txt
# Paste the first two columns of the first file: gene name and description
# Paste the 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced and 48_Induced as WT the C1 for each one
# Output to intermediate file
paste <(cut -f1 WT_fold_changes.txt) <(cut -f2 WT_fold_changes.txt) <(cut -f3 WT_fold_changes.txt) <(cut -f3 C1_fold_changes.txt) <(cut -f4 WT_fold_changes.txt) <(cut -f4 C1_fold_changes.txt) <(cut -f5 WT_fold_changes.txt) <(cut -f5 C1_fold_changes.txt) <(cut -f6 WT_fold_changes.txt) <(cut -f6 C1_fold_changes.txt) <(cut -f7 WT_fold_changes.txt) <(cut -f7 C1_fold_changes.txt) > WT_VS_C1.fold_changes_wo_header.txt

#Define Variables for headings - there will be two rows for headings - 
#WT, C1 and Gene Name, Gene Description, 0_Uninduced etc .. (the latter inc in cut and paste cmd above)
blank=" "
WT="WT"
C1="C1"
FC1="FC_0_U"
FC2="FC_24_U"
FC3="FC_48_U"
FC4="FC_24_I"
FC5="FC_48_I"

#Echo to intermediate file the headings blank spacex2, WT, C1, WT, C1, WT, C1 etc ..- so you know which file the 0_Uninduced column etc belong to
echo -e "$blank\t$blank\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1" | cat - WT_VS_C1.fold_changes_wo_header.txt > WT_VS_C1.fold_changes.txt

#To find the fold change difference between WT and C1 for each 0_Uninduced etc
#Divide the value for the gene in the WT sample by the corresponding C1 value
#There is a pssibility of a zero-division error so specify that if the denominator=0 to print "UND"
#Repeat for each pair of columns for example 0_Uninduced in WT and C1 and output to intermediate files 
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($3 != 0) {fold = $4/ $3; $13 = sprintf("%.2f", fold)} else {$13="UND"} print}' WT_VS_C1.fold_changes.txt > WT_C1.1.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($5 != 0) {fold = $6/ $5; $14 = sprintf("%.2f", fold)} else {$14="UND"} print}' WT_C1.1.txt > WT_C1.2.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($7 != 0) {fold = $8/ $7; $15 = sprintf("%.2f", fold)} else {$15="UND"} print}' WT_C1.2.txt > WT_C1.3.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($9 != 0) {fold = $10/ $9; $16 = sprintf("%.2f", fold)} else {$16="UND"} print}' WT_C1.3.txt > WT_C1.4.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($11 != 0) {fold = $12/ $11; $17 = sprintf("%.2f", fold)} else {$17="UND"} print}' WT_C1.4.txt > WT_C1.5.txt

#Sort the fold changes in descending order according to the 48_Induced file- This has been arbitarily chosen- NEEDS TO BE FIXED
sort -s -nr -k 17 WT_C1.5.txt > WT_C1.6.txt

#Print headings for each
echo -e "$blank\t$blank\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$FC1\t$FC2\t$FC3\t$FC4\t$FC5" | cat - WT_C1.6.txt > final_WT_VS_C1.fold_changes.txt

#WT VS C2
#Repeat the exact same commands for WT VS C2
paste <(cut -f1 WT_fold_changes.txt) <(cut -f2 WT_fold_changes.txt) <(cut -f3 WT_fold_changes.txt) <(cut -f3 C2_fold_changes.txt) <(cut -f4 WT_fold_changes.txt) <(cut -f4 C2_fold_changes.txt) <(cut -f5 WT_fold_changes.txt) <(cut -f5 C2_fold_changes.txt) <(cut -f6 WT_fold_changes.txt) <(cut -f6 C2_fold_changes.txt) <(cut -f7 WT_fold_changes.txt) <(cut -f7 C2_fold_changes.txt) > WT_VS_C2.fold_changes_wo_header.txt

C2="C2"

echo -e "$blank\t$blank\t$WT\t$C2\t$WT\t$C2\t$WT\t$C2\t$WT\t$C2\t$WT\t$C2" | cat - WT_VS_C2.fold_changes_wo_header.txt > WT_VS_C2.fold_changes.txt

#Trying to minimise the number of intermediate files- not working
#tee >(awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($4 != 0) {fold = $3/ $4; $13 = sprintf("%.3f", fold)} else {$13="UND"} print}' WT_VS_C2.fold_changes.txt) >(awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($6 != 0) {fold = $5/ $6; $14 = sprintf("%.3f", fold)} else {$14="UND"} print}') >(awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($8 != 0) {fold = $7/ $8; $15 = sprintf("%.3f", fold)} else {$15="UND"} print}') >(awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($10 != 0) {fold = $9/ $10; $16 = sprintf("%.3f", fold)} else {$16="UND"} print}') >(awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($12 != 0) {fold = $11/ $12; $13 = sprintf("%.3f", fold)} else {$17="UND"} print}') >(sort -nr -k 17 WT_VS_C2.fold_changes.txt) > TRIAL.2_WT_VS_C2.fold_changes.txt

awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($3 != 0) {fold = $4/ $3; $13 = sprintf("%.2f", fold)} else {$13="UND"} print}' WT_VS_C2.fold_changes.txt > WT_C2.1.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($5 != 0) {fold = $6/ $5; $14 = sprintf("%.2f", fold)} else {$14="UND"} print}' WT_C2.1.txt > WT_C2.2.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($7 != 0) {fold = $8/ $7; $15 = sprintf("%.2f", fold)} else {$15="UND"} print}' WT_C2.2.txt > WT_C2.3.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($9 != 0) {fold = $10/ $9; $16 = sprintf("%.2f", fold)} else {$16="UND"} print}' WT_C2.3.txt > WT_C2.4.txt 
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($11 != 0) {fold = $12/ $11; $17 = sprintf("%.2f", fold)} else {$17="UND"} print}' WT_C2.4.txt > WT_C2.5.txt

sort -s -nr -k 17 WT_C2.5.txt > WT_C2.6.txt

echo -e "$blank\t$blank\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$FC1\t$FC2\t$FC3\t$FC4\t$FC5" | cat - WT_C2.6.txt > final_WT_VS_C2.fold_changes.txt

#C1 VS C2 
# Repeat the exact same commands for C1 and C2
paste <(cut -f1 C1_fold_changes.txt) <(cut -f2 C1_fold_changes.txt) <(cut -f3 C1_fold_changes.txt) <(cut -f3 C2_fold_changes.txt) <(cut -f4 C1_fold_changes.txt) <(cut -f4 C2_fold_changes.txt) <(cut -f5 C1_fold_changes.txt) <(cut -f5 C2_fold_changes.txt) <(cut -f6 C1_fold_changes.txt) <(cut -f6 C2_fold_changes.txt) <(cut -f7 C1_fold_changes.txt) <(cut -f7 C2_fold_changes.txt) > C1_VS_C2.fold_changes_wo_header.txt

echo -e "$blank\t$blank\t$C1\t$C2\t$C1\t$C2\t$C1\t$C2\t$C1\t$C2\t$C1\t$C2" | cat - C1_VS_C2.fold_changes_wo_header.txt > C1_VS_C2.fold_changes.txt

awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($3 != 0) {fold = $4/ $3; $13 = sprintf("%.2f", fold)} else {$13="UND"} print}' C1_VS_C2.fold_changes.txt > C1_C2.1.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($5 != 0) {fold = $6/ $5; $14 = sprintf("%.2f", fold)} else {$14="UND"} print}' C1_C2.1.txt > C1_C2.2.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($7 != 0) {fold = $8/ $7; $15 = sprintf("%.2f", fold)} else {$15="UND"} print}' C1_C2.2.txt > C1_C2.3.txt
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($9 != 0) {fold = $10/ $9; $16 = sprintf("%.2f", fold)} else {$16="UND"} print}' C1_C2.3.txt > C1_C2.4.txt 
awk -F '\t' -v OFS='\t' 'FNR > 2 { if ($11 != 0) {fold = $12/ $11; $17 = sprintf("%.2f", fold)} else {$17="UND"} print}' C1_C2.4.txt > C1_C2.5.txt

sort -s -nr -k 17 C1_C2.5.txt > C1_C2.6.txt


echo -e "$blank\t$blank\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$WT\t$C1\t$FC1\t$FC2\t$FC3\t$FC4\t$FC5" | cat - C1_C2.6.txt > final_C1_VS_C2.fold_changes.txt
