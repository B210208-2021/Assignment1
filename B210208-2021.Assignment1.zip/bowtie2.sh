#!usr/bin/bash 

#This script will read on the paired sequence files, run the bowtie command on these files, and output the files in a bam formatted file.
#Need to build a reference file from the segmented file with bowtie2 builder first
#Execute the bowtie2 command 
#The bam formatted files will be indexed then

#Introduce Variables 
# Give the path to the file aswell
TC_File = $1

#Copy the file to the current working directory, unzip the file and build the reference genome
cp $TC_File . | unzip $TC_File > unzipped_TC_File.fasta

bowtie2-build unzipped_TC_File.fasta  TC 

# Run a for loop over all the files in the paired sequences and excute the bowtie2 command 
for file in $(ls *_1.fq.gz);
do 
file_ext= echo "$file" | cut -f1 -d_ 
bowtie2 -p 4 --very-fast-local -1 "$file_ext"_1.fq.gz  -2 "$file_ext"_2.fq.gz -x TC | samtools view -b -@ 4 | samtools sort -@4 > "$file_ext".bam
samtools index "$file_ext".bam;
done

#100k.C1-1-501_1.fq.gz
