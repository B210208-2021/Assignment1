#!/usr/bin/bash

#Assess the FastQC report
#Ask user to input the desired modules to assess
#This will be done as the modules assessed should be done with respect with the specific experiment and analysis the user wants to do
#Print the results
#Ask user if they wish to continue

#Loop over the files created from the FastQC script 
#Files will be in CWD so no need for full file path
#Set the variable rest_of_script to first variable in command line input
rest_of_script=$1
#Set the variables WARN and FAIL
w="WARN"
f="FAIL"

#Ask user if they wish to assess a module
#While the user wishes to assess different modules
#Ask which module they would like to assess
#Print filename and line with the warn or fail message associated with the module of the files with that specific module that have warn or fail messages
#If user says no then print associated message and exit the code  
#If user inputs anything or than yes or no tell them to specify one and ask the prompt again
while true; do
read -p "Would you like to assess the individual modules of the FastQC reports?" answer
case "$answer" in 

[Yy]es) read -p "modules:" modules 

echo "The module the user wishes to assess is" $modules

filename=$(echo $modules | sed 's/ /_/g')

for file in $(ls *_fastqc/summary.txt); do grep -s -e $w.*$modules -e $f.*$modules $file >> "$filename"_WARN_FAIL.txt; done ;;

[Nn]o) echo "User does not wish to assess any modules." 

break ;;

*) echo "Please specify Yes or No." ;;

esac
done

less "$filename"_WARN_FAIL.txt

read -p "Do you wish to continue?" response
case "$response" in

[Yy]es) source $rest_of_script ;;

[Nn]o) echo "The user did not wish to continue."

break ;;

*) echo "Please specify Yes or No." 

break ;;
esac

#yes=$(read -p "modules:" modules; echo "The module is" $modules; filename=$(echo $modules | sed 's/ /_/g');
#for file in $(ls *_fastqc/summary.txt); do grep -s -e $w.*$modules -e $f.*$modules $file >> "$filename"_WARN_FAIL.txt; done)
#no=$(echo "User does not wish to assess any modules")
#not_sure=$(echo "Please specify Yes or No")
#Ask the user if they would like to assess the different modules
#read -p "Would you like to assess the individual modules of the FastQC reports?" answer
#if [$answer == "Yes"];
#then
#yes=$(echo "Hi"; echo "keep going"; echo "you will figure this")
#case $answer in
#Ask the user to input the modules they want to assess

#Yes|yes) echo $yes ;;

#read -p "modules:" modules

#echo "The module is" $modules

#filename=$(echo $modules | sed 's/ /_/g')

#Loop over the files and 
#for file in $(ls *_fastqc/summary.txt); do while read line; do if [[$line =~ FAIL|WARN $module]]; then echo $line; fi; done < $file; done
#for file in $(ls *_fastqc/summary.txt); do grep -s -e $w.*$modules -e $f.*$modules $file >> "$filename"_WARN_FAIL.txt 

 
#No|no) echo $no ;;

#*) echo $not_sure ;;

#esac
#else
  
#break
 
#fi 

#Print for each file what parameters passed or failed

#If the file failed certain parameters or an abritrary number of parameters ; print a warning message about the sequences 

#Ask User if they would wish to proceed
