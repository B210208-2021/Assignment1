#!/usr/bin/bash

#Write full path name with filename
TC_File=$1

#echo $TC_File

#Copy the file to the current working directory, unzip the file and build the reference genome
cp $TC_File .

file_name=`basename $TC_File`
file_name_2=`basename $TC_File .gz`

#file2=echo $file_name | sed 's/\.gz//g'

#echo "file name is $file_name"

#echo "file 2 is $file_name_2"

gzip -d $file_name


bowtie2-build $file_name_2 TC

# Run a for loop over all the files in the paired sequences and excute the bowtie2 command
for file in $(ls /localdisk/data/BPSM/AY21/fastq/*_1.fq.gz);
do
fname=`basename $file  _1.fq.gz`
#file_ext= echo "$file" | cut -f1 -d_
bowtie2 -p 4 --very-fast-local -1 /localdisk/data/BPSM/AY21/fastq/"$fname"_1.fq.gz  -2 /localdisk/data/BPSM/AY21/fastq/"$fname"_2.fq.gz -x TC | samtools view -b -@ 4 | samtools sort -@4 > "$fname".bam
samtools index "$fname".bam;
done


#Loop over the WT output files from sorting_script.sh
#Loop over file names in each file to sort into bam 1, 2 and 3
# Generate counts data for 3 separate files and output file with gene name, gene description, file1 count, file2 count and file3 count
# Then want to sum either individual columns and get mean and/or all columns and get mean
#Print that output to a file for each WT, C1, and C2
#A script that generates count data for the 3 separate  files and outputs the file with the gene name, gene description, file1 count, file2 count, file3 count

#WT
for file in $(ls *_WT_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt > "$filename"_av_counts.txt
echo $filename | cut -f 6 "$filename"_av_counts.txt >> WT_av_counts.txt
done



#C1
for file in $(ls *_C1_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt  > "$filename"_av_counts.txt
done

#C2
for file in $(ls *_C2_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt  > "$filename"_av_counts.txt
done

#List the files _*_av_counts.txt
#Loop over these files and make a column for each filename
#Print the gene name and description
#Cut and paste the column 6 in each file under the heading


#WT
#List the WT_av_count.txt files, sort them numerically, and output to new file
ls *_WT_av_counts.txt | sort  > total_WT_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_WT_av_counts.txt/ /g' total_WT_av_counts.txt | sort  > sed.total_WT_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_WT_av_counts.txt;
do
for l in total_WT_av_counts.txt;
do
#Define variables to hold the Gene Name and the Description Headings
name="Gene_Name"
des="Gene_Description"
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > WT_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - WT_fold_changes_wo_header.txt > WT_fold_changes.txt
done
done

name="Gene_Name"
des="Gene_Description"
n1="0_Uninduced"
n2="24_Uninduced"
n3="48_Uninduced"
n4="24_Induced"
n5="48_Induced"
FC1="FC_0_U_VS_24_I"
FC2="FC_0_U_VS_48_I"
FC3="FC_24_U_VS_24_I"
FC4="FC_24_U_VS_48_I"
FC5="FC_48_U_VS_24_I"
FC6="FC_48_U_VS_48_I"

#Compare 0_Uninduced && 24_Uninduced && 48_Uninduced to 24_Induced and 48_Induced
#Compare 0_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $6/ $3; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_0_U_24_I_fold_changes_wo_header.txt
echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC1" | cat - WT_0_U_24_I_fold_changes_wo_header.txt > WT_0_U_24_I_fold_changes.txt

#Compare 0_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $7/ $3; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_0_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC2" | cat - WT_0_U_48_I_fold_changes.wo.header.txt > WT_0_U_48_I_fold_changes.txt

#Compare 24_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $6/ $4; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_24_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC3" | cat - WT_24_U_24_I_fold_changes.wo.header.txt > WT_24_U_24_I_fold_changes.txt

#Compare 24_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $7/ $4; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_24_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC4" | cat - WT_24_U_48_I_fold_changes.wo.header.txt > WT_24_U_48_I_fold_changes.txt

#Compare 48_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $6/ $5; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_48_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC5" | cat - WT_48_U_24_I_fold_changes.wo.header.txt > WT_48_U_24_I_fold_changes.txt

#Compare 24_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $7/ $5; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' WT_fold_changes.txt | sort -nr -k 8 > WT_48_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC6" | cat - WT_48_U_48_I_fold_changes.wo.header.txt > WT_48_U_48_I_fold_changes.txt


#C1
#List the C1_av_count.txt files, sort them numerically, and output to new file
ls *_C1_av_counts.txt | sort  > total_C1_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_C1_av_counts.txt/ /g' total_C1_av_counts.txt | sort  > sed.total_C1_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_C1_av_counts.txt;
do
for l in total_C1_av_counts.txt;
do
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > C1_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - C1_fold_changes_wo_header.txt > C1_fold_changes.txt
done
done

#Compare 0_Uninduced && 24_Uninduced && 48_Uninduced to 24_Induced and 48_Induced
#Compare 0_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $6/ $3; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_0_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC1"| cat - C1_0_U_24_I_fold_changes.wo.header.txt > C1_0_U_24_I_fold_changes.txt

#Compare 0_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $7/ $3; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_0_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC2" | cat - C1_0_U_48_I_fold_changes.wo.header.txt > C1_0_U_48_I_fold_changes.txt

#Compare 24_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $6/ $4; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_24_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC3" | cat - C1_24_U_24_I_fold_changes.wo.header.txt > C1_24_U_24_I_fold_changes.txt

#Compare 24_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $7/ $4; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_24_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC4" | cat - C1_24_U_48_I_fold_changes.wo.header.txt > C1_24_U_48_I_fold_changes.txt

#Compare 48_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $6/ $5; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_48_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC5" | cat - C1_48_U_24_I_fold_changes.wo.header.txt > C1_48_U_24_I_fold_changes.txt

#Compare 48_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $7/ $5; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C1_fold_changes.txt | sort -nr -k 8 > C1_48_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC6" | cat - C1_48_U_48_I_fold_changes.wo.header.txt > C1_48_U_48_I_fold_changes.txt

#C2
#List the C2_av_count.txt files, sort them numerically, and output to new file
ls *_C2_av_counts.txt | sort  > total_C2_av_counts.txt
#Replace the file extensions with a empty space, sort these files numerically and output to new file
sed 's/_C2_av_counts.txt/ /g' total_C2_av_counts.txt | sort  > sed.total_C2_av_counts.txt
#First loop over the lines of the sorted filenames without (wo) the file extension and then the lines (l) of the file with full filenames sorted numerically
for line in sed.total_C2_av_counts.txt;
do
for l in total_C2_av_counts.txt;
do
#Move down the file lines and set each value of each line as a different var variable- var1, var2 etc...
eval $(awk '{print "var"NR"="$1}' $line)
#Move down the file lines and set each value of each as a different file variable- file1, file2 etc..
eval $(awk '{print "file"NR"="$1}' $l)
# Cut and paste the individual required columns together
# Note with the difficulty with sorting by numeric instead of numeric and then by the third character- the order of the filenames are changed
# This is so that the columns are Gene_name, Gene_des, 0_Uninduced, 24_Uninduced, 48_Uninduced, 24_Induced, and 48_Induced
#Output to intermediate file
paste <(cut -f1 $file1) <(cut -f2 $file1) <(cut -f6 $file1) <(cut -f6 $file3) <(cut -f6 $file5) <(cut -f6 $file2) <(cut -f6 $file4) > C2_fold_changes_wo_header.txt
#Echo the headings for each of these files as the variables set earlier and separated each by a tab-delimiter and output to final file
echo -e "$name\t$des\t$var1\t$var3\t$var5\t$var2\t$var4" | cat - C2_fold_changes_wo_header.txt > C2_fold_changes.txt
done
done

#Compare 0_Uninduced && 24_Uninduced && 48_Uninduced to 24_Induced and 48_Induced
#Compare 0_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $6/ $3; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_0_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC1" | cat - C2_0_U_24_I_fold_changes.wo.header.txt > C2_0_U_24_I_fold_changes.txt

#Compare 0_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($3 != 0) {fold = $7/ $3; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_0_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC2" | cat - C2_0_U_48_I_fold_changes.wo.header.txt > C2_0_U_48_I_fold_changes.txt

#Compare 24_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $6/ $4; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_24_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC3" | cat - C2_24_U_24_I_fold_changes.wo.header.txt > C2_24_U_24_I_fold_changes.txt

#Compare 24_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($4 != 0) {fold = $7/ $4; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_24_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC4" | cat - C2_24_U_48_I_fold_changes.wo.header.txt > C2_24_U_48_I_fold_changes.txt

#Compare 48_Uninduced to 24_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $6/ $5; $8 = sprintf("%.2f", fold)} else {$8=$6} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_48_U_24_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC5" | cat - C2_48_U_24_I_fold_changes.wo.header.txt > C2_48_U_24_I_fold_changes.txt

#Compare 48_Uninduced to 48_Induced
awk -F '\t' -v OFS='\t' 'FNR > 1 { if ($5 != 0) {fold = $7/ $5; $8 = sprintf("%.2f", fold)} else {$8=$7} print}' C2_fold_changes.txt | sort -nr -k 8 > C2_48_U_48_I_fold_changes.wo.header.txt

echo -e "$name\t$des\t$n1\t$n2\t$n3\t$n4\t$n5\t$FC6" | cat - C2_48_U_48_I_fold_changes.wo.header.txt > C2_48_U_48_I_fold_changes.txt

