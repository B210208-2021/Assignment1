#!/usr/bin/bash

# Three Scripts that take a list of WT, C1, and C2
#Loop over the WT output files from sorting_script.sh 
#Loop over file names in each file to sort into bam 1, 2 and 3
# Generate counts data for 3 separate files and output file with gene name, gene description, file1 count, file2 count and file3 count
# Then want to sum either individual columns and get mean and/or all columns and get mean
#Print that output to a file for each WT, C1, and C2
#A script that generates count data for the 3 separate  files and outputs the file with the gene name, gene description, file1 count, file2 count, file3 count

#WT
for file in $(ls *_WT_files.txt);
do
filename=`basename $file _files.txt` 
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt > "$filename"_av_counts.txt
echo $filename | cut -f 6 "$filename"_av_counts.txt >> WT_av_counts.txt
done



#C1
for file in $(ls *_C1_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt  > "$filename"_av_counts.txt
done

#C2
for file in $(ls *_C2_files.txt);
do
filename=`basename $file _files.txt`
eval $(awk '{print "var"NR"="$1}' $file)
bedtools multicov -bams $var1 $var2 $var3 -bed /localdisk/data.local/BPSM/Feb2021/TriTrypDB-46_TcongolenseIL3000_2019.bed > "$filename".bed
cut -f 1,5,6,7,8  "$filename".bed > "$filename"_counts.txt
awk -F '\t' '{OFS="\t"; sum=0; N=3; for (i=3; i<=NF; i++) {sum=sum+$i;} m=sum/N; print $1,$2,$3,$4,$5,m; }' "$filename"_counts.txt  > "$filename"_av_counts.txt
done


