#!/usr/bin/bash

#Variable 1 is the path to the file 
PATH= $1
OUTPUT_DIR=$2

cd $PATH
for file in (ls $PATH/*.fq.gz)
do 
fastqc $file -o $OUTPUT_DIR
done
