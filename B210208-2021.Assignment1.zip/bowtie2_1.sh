#!/usr/bin/bash

#Write full path name with filename
TC_File=$1

#echo $TC_File

#Copy the file to the current working directory, unzip the file and build the reference genome
cp $TC_File . 

file_name=`basename $TC_File`
file_name_2=`basename $TC_File .gz`

#file2=echo $file_name | sed 's/\.gz//g' 

#echo "file name is $file_name"

#echo "file 2 is $file_name_2"

gzip -d $file_name 


bowtie2-build $file_name_2 TC

# Run a for loop over all the files in the paired sequences and excute the bowtie2 command
for file in $(ls /localdisk/data/BPSM/AY21/fastq/*_1.fq.gz);
do
fname=`basename $file  _1.fq.gz`
#file_ext= echo "$file" | cut -f1 -d_
bowtie2 -p 4 --very-fast -1 /localdisk/data/BPSM/AY21/fastq/"$fname"_1.fq.gz  -2 /localdisk/data/BPSM/AY21/fastq/"$fname"_2.fq.gz -x TC | samtools view -b -@ 4 | samtools sort -@4 > "$fname".bam
samtools index "$fname".bam;
done



