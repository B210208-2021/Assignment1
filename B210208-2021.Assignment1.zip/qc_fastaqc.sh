#!/usr/bin/bash

#Assess the FastQC report
#Ask user to input the desired modules to assess
#This will be done as the modules assessed should be done with respect with the specific experiment and analysis the user wants to do
#Print the results
#Ask user if they wish to continue

#Loop over the files created from the FastQC script 
#Files will be in CWD so no need for full file path

#Set the variables WARN and FAIL
w="WARN"
f="FAIL"
yes=$(read -p "modules:" modules; echo "The module is" $modules; filename=$(echo $modules | sed 's/ /_/g'); for file in $(ls *_fastqc/summary.txt); do grep -s -e $w.*$modules -e $f.*$modules $file >> "$filename"_WARN_FAIL.txt)
no=$(echo "User does not wish to assess any modules")
not_sure=$(echo "Please specify Yes or No")
#Ask the user if they would like to assess the different modules
read -p "Would you like to assess the individual modules of the FastQC reports?" answer
#if [$answer == "Yes"];
#then

case $answer in
#Ask the user to input the modules they want to assess

Yes|yes) echo $yes ;;

#read -p "modules:" modules

#echo "The module is" $modules

#filename=$(echo $modules | sed 's/ /_/g')

#Loop over the files and 
#for file in $(ls *_fastqc/summary.txt); do while read line; do if [[$line =~ FAIL|WARN $module]]; then echo $line; fi; done < $file; done
#for file in $(ls *_fastqc/summary.txt); do grep -s -e $w.*$modules -e $f.*$modules $file >> "$filename"_WARN_FAIL.txt 

 
No|no) echo $no ;;

*) echo $not_sure ;;

esac
#else
  
#break
 
#fi 

#Print for each file what parameters passed or failed

#If the file failed certain parameters or an abritrary number of parameters ; print a warning message about the sequences 

#Ask User if they would wish to proceed
