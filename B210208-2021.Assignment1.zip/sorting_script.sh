#!/usr/bin/bash

# Script that sorts the files into the different replicates

PATH=$1

#0 Uninduced, WT
awk '{if ($2=="WT" && $4=="0") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 0_Uninduced_WT.txt

#24 Uninduced, WT
awk '{if ($2=="WT" && $4=="24") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 24_Uninduced_WT.txt

#48 Uninduced, WT
awk '{if ($2=="WT" && $4=="48") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Uninduced_WT.txt

#0 Uninduced, C1
awk '{if ($2=="Clone1" && $4=="0") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 0_Uninduced_C1.txt

#24 Uninduced, C1
awk '{if ($2=="Clone1" && $4=="24") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 24_Uninduced_C1.txt

#48 Uninduced, C1
awk '{if ($2=="Clone1" && $4=="48") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Uninduced_C1.txt

#0 Uninduced, C2
awk '{if ($2=="Clone2" && $4=="0") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 0_Uninduced_C2.txt

#24 Uninduced, C2
awk '{if ($2=="Clone2" && $4=="24") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 24_Uninduced_C2.txt

#48 Uninduced, C2
awk '{if ($2=="Clone2" && $4=="48") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Uninduced_C2.txt

#24 Induced, WT
awk '{if ($2=="WT" && $4=="24") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 24_Induced_WT.txt

#48 Induced, WT
awk '{if ($2=="WT" && $4=="48") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Induced_WT.txt

#24 Induced, C1
awk '{if ($2=="Clone1" && $4=="24") print $1, $2, $3, $4}'$PATH/100k.fqfiles > 24_Induced_C1.txt

#48 Induced, C1
awk '{if ($2=="Clone1" && $4=="48") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Induced_C1.txt

#24 Induced, C2
awk '{if ($2=="Clone2" && $4=="0") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 24_Induced_C2.txt

#48 Induced, C2
awk '{if ($2=="Clone2" && $4=="0") print $1, $2, $3, $4}' $PATH/100k.fqfiles > 48_Induced_C2.txt
